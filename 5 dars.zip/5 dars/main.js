function checkSchoolEligibility(age) {
  if (age < 7) {
    return "O'quvchi maktabda o'qiy olmaydi.";
  } else if (age > 17) {
    return "Siz maktabni bitirgansiz.";
  } else {
        return "Xush kelibsiz!"
  }
}

console.log(checkSchoolEligibility(5)); 
output 
console.log(checkSchoolEligibility(10));
console.log(checkSchoolEligibility(18));
console.log(checkSchoolEligibility(7));  
console.log(checkSchoolEligibility(17)); 